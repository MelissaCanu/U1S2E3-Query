SELECT OrderID, SUM(UnitPrice * Quantity) AS TOTORDBYSINGLEID FROM [Order Details] WHERE OrderID = 10248 GROUP BY OrderID
--qua non ho capito perch� ci va GROUP BY per forza